function varargout = ass2(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @assignment2_OpeningFcn, ...
                   'gui_OutputFcn',  @assignment2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before assignment2 is made visible.
function assignment2_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

function varargout = assignment2_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;


% --- Executes on button press in upload_picture.

function upload_picture_Callback(hObject, eventdata, handles)

[filename, pathname] = uigetfile('*.*', 'Pick a MATLAB code file');

% now to read the image we will use the command imread and save it in the variable “a”.
if isequal(filename,0) || isequal(pathname,0)
       disp('User pressed cancel')
else
      filename=strcat(pathname,filename);
      a=imread(filename);
      axes(handles.axes1);
      imshow(a);
      handles.a = a;
 
% Update handles structure
      guidata(hObject, handles);
 
end

% --- Executes on button press in threshold.
function threshold_Callback(hObject, eventdata, handles)
j=handles.a;
level = graythresh(j);
BW = imbinarize(j,level);
imshowpair(j,BW,'montage')

      handles.j = j;
 
% Update handles structure
      guidata(hObject, handles);

% --- Executes on button press in gamma.
%function gamma_Callback(hObject, eventdata, handles)

% --- Executes on button press in zoom_out.
function zoom_out_Callback(hObject, eventdata, handles)
j=handles.a;
j = uint8(j);
[row,col] = size(j);
%K = uint8(zeros(row,col));

for i = 1:row/2
    for k = 1:col/2
        p = i*2;
        q = k*2;

        j(i,k) = j(p,q);
    end
end
      imshow(j);
       handles.j = j;
 
% Update handles structure
      guidata(hObject, handles);

% --- Executes on button press in noise.
function noise_Callback(hObject, eventdata, handles)

j=handles.a;
        j = imnoise(j,'salt & pepper', 0.4);
      axes(handles.axes1);
      imshow(j);
       handles.j = j;
 
% Update handles structure
      guidata(hObject, handles);


% --- Executes on button press in avg_filter.
function avg_filter_Callback(hObject, eventdata, handles)
j=handles.a;

j = imfilter(j, ones(9)/81, 'symmetric');
imshow(j);
       handles.j = j;
 
% Update handles structure
      guidata(hObject, handles);


% --- Executes on button press in closing.
function closing_Callback(hObject, eventdata, handles)

j=handles.a;

se = strel('disk',10);

j = imclose(j,se);
imshow(j);

       handles.j = j;
 
% Update handles structure
      guidata(hObject, handles);

% --- Executes on button press in prewitt.
function prewitt_Callback(hObject, eventdata, handles)
j=handles.a;

j = mean(j,3);
px = [-1 0 1; -1 0 1; -1 0 1];
j = filter2(px,j);
imshow(j/255)

       handles.j = j;
 
% Update handles structure
      guidata(hObject, handles);

% --- Executes on button press in neg_lap.
%function neg_lap_Callback(hObject, eventdata, handles)


