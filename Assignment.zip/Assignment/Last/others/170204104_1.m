I = imread('image1.jpg');

[img,laplacianFilterApply,enhencedImage,sobel_sqrt_img,avgFilter_img,productImage,addedImage,power_law_image] = allFiltertApply(I);

fig = figure('WindowState','maximized');
subplot(2, 4, 1);imshow(I);title("Step 1");
subplot(2, 4, 2);imshow(laplacianFilterApply,[]);title("Step 2");
subplot(2, 4, 3);imshow(enhencedImage);title("Step 3");
subplot(2, 4, 4);imshow(sobel_sqrt_img);title("Step 4");
subplot(2, 4, 5);imshow(avgFilter_img);title("Step 5");
subplot(2, 4, 6);imshow(productImage);title("Step 6");
subplot(2, 4, 7);imshow(addedImage);title("Step 7");
subplot(2, 4, 8);imshow(power_law_image);title("Step 8");
saveas(fig,'Output','jpg');


function [img,laplacianFilterApply,enhencedImage,sobel_sqrt_img,avgFilter_img,productImage,addedImage,power_law_image] = allFiltertApply(img)
    img = img;
    I2d = im2double(img);
    laplacianFilterApply = posLaplacianFilterApply(I2d);
    enhencedImage = I2d - laplacianFilterApply;
    [sobel_g_x_img,sobel_g_y_img,sobel_sqrt_img] = sobelFilterApply(I2d);
    avgFilter_img = avgFilterApply(sobel_sqrt_img);
    productImage  = enhencedImage .* avgFilter_img;
    addedImage  = I2d + productImage;
    c = 1;
    gamma_value = 0.5;
    power_law_image = powerLawImage(c,gamma_value,I2d);
end

function pos_lap = posLaplacianFilterApply(img)
    lap_filter = [
        0 1 0; 
        1 -4 1;
        0 1 0
     ];
    [row,col] = size(img);
    newimage = zeros([row col]);
    pad = 2;
    for i = 1 : row - pad
        for j = 1 : col - pad
            temp = img(i : i + pad, j : j + pad) .* lap_filter;
            newimage(i + 2, j + 2) = sum(temp( : ));
        end
    end

    pos_lap = newimage;
end

function avgFilter_img = avgFilterApply(img)
    avgFilter_mat = 1/25 * ones(5,5);
    
    [row,col] = size(img);
    newimage = zeros([row col]);
    pad = 4;
    for i = 1 : row - pad
        for j = 1 : col - pad
            temp = img(i : i + pad, j : j + pad) .* avgFilter_mat;
            newimage(i + 2, j + 2) = sum(temp( : ));
        end
    end
    avgFilter_img = newimage;
end

function power_law_image = powerLawImage(c,gamma_value,img)
    c = 1;
    gamma_value = 0.5;
    power_law_image = c * (img .^ gamma_value);
end


function [sobel_g_x_img,sobel_g_y_img,sobel_sqrt_img] = sobelFilterApply(I2d)
    img = I2d;
    sobel_threshold = 0.0;
    sobel_g_x_mat = [
        -1 0 1; 
        -2 0 2; 
        -1 0 1
    ];
    sobel_g_y_mat = [
        1 2 1; 
        0 0 0; 
        -1 -2 -1
    ];

    [row,col] = size(img);
    newimage = zeros([row col]);
    newimage2 = zeros([row col]);
    pad = 2;
    for i = 1 : row - pad
        for j = 1 : col - pad
            temp = img(i : i + pad, j : j + pad) .* sobel_g_x_mat;
            newimage(i + 2, j + 2) = sum(temp( : ));
            temp = img(i : i + pad, j : j + pad) .* sobel_g_y_mat;
            newimage2(i + 2, j + 2) = sum(temp( : ));
        end
    end
    sobel_g_x_img = newimage;
    sobel_g_y_img = newimage2;
    sobel_sqrt_img = sqrt(sobel_g_x_img .^ 2 + sobel_g_y_img .^ 2);
    
    [row, col] = size(sobel_sqrt_img);

    for i = 1 : row
        for j = 1 : col
            if(sobel_sqrt_img(i, j) < sobel_threshold)
                sobel_sqrt_img(i, j) = 0;
            end
        end
    end
    
    sobel_sqrt_img = sobel_sqrt_img;
end


