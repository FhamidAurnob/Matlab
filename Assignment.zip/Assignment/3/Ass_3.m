%Read an Image
Img1 = imread('cameraman.png');


A = imnoise(Img1,'Gaussian',0.04,0.003);

%imnoise(I,'Gaussian',intensity_map,var_local)

I = double(A);

%Design the Gaussian Kernel
%Standard Deviation

sigma_val = 'Enter the sigma value = ';
sigma = input(sigma_val);

%Window size
sz = 2;
[x,y] = meshgrid(-sz:sz,-sz:sz)

M = size(x,1)-1;
N = size(y,1)-1;
Exp_comp = -(x.^2+y.^2)/(2*sigma*sigma);
Kernel= exp(Exp_comp)/(2*pi*sigma*sigma);
Kernel
%Initialize
Output=zeros(size(I));
%Pad the vector with zeros
I = padarray(I,[sz sz]);
 
%Convolution
for i = 1:size(I,1)-M
    for j =1:size(I,2)-N
        Temp = I(i:i+M,j:j+M).*Kernel;
        Output(i,j)=sum(Temp(:));
    end
end
%Image without Noise after Gaussian blur
Output = uint8(Output);

%Image with noise

subplot(1,2,1),imshow(A),title("Orginal Image");
subplot(1,2,2),imshow(Output),title("After Gausian Filter");
