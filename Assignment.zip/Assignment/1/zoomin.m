I= imread('cameraman.png');
figure;
%I=rgb2gray(I);
s=size(I);
c=[];
d=[];
zoom=7;

for n=1:s(1,1)
    for p=1:zoom
        c=[c;I(n,:)];
    end
end

for m=1:s(1,2)
    for p=1:zoom
        d=[d,c(:,m)];
    end
end

imshow(d);