I=imread('G:\From D Drive\4.2\Digital Image Processing\Lab\Assignment\1\apple.jpeg');
figure;
I=rgb2gray(I);
s=size(I);
c=[];
d=[];
zoom=input('enter zooming out factor');

for n=1:zoom:s(1,1)
 
        c=[c;I(n,:)];
end
 
for m=1:zoom:s(1,2)
   
        d=[d,c(:,m)];
end
imshow(d);
title('after zooming out');