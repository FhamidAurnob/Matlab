a = imread('cameraman.png');
[m,n] = size(a);

for i = 1:2*m
    for j = 1: 2*n
        p = i - floor(i/2);
        q = j - floor(j/2);
        
        b(i,j) = a(p,q);
        
    end
end

figure;imshow(a)
title('Original Image');
figure;imshow(b)
title('Zoom in Image');

for i = 1: m/2
    for j = 1: n/2
        p =  i*2;
        q =  j*2;
        
        c(i,j) = a(p,q);
        
    end
end

figure;imshow(c)
title('Zoom Out Image');